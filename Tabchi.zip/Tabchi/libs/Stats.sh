﻿memTotal_b=`free -b |grep Mem |awk '{print $2}'`
memFree_b=`free -b |grep Mem |awk '{print $4}'`
memBuffer_b=`free -b |grep Mem |awk '{print $6}'`
memCache_b=`free -b |grep Mem |awk '{print $7}'`

memTotal_m=`free -m |grep Mem |awk '{print $2}'`
memFree_m=`free -m |grep Mem |awk '{print $4}'`
memBuffer_m=`free -m |grep Mem |awk '{print $6}'`
memCache_m=`free -m |grep Mem |awk '{print $7}'`
CPUPer=`top -b -n1 | grep "Cpu(s)" | awk '{print $2 + $4}'`
uptime=`uptime`
ProcessCnt=`ps -A | wc -l`
memUsed_b=$(($memTotal_b-$memFree_b-$memBuffer_b-$memCache_b))
memUsed_m=$(($memTotal_m-$memFree_m-$memBuffer_m-$memCache_m))
memUsedPrc=$((($memUsed_b*100)/$memTotal_b))
echo "•SERVER INFO•"
echo "             "
echo "•Ram : $memTotal_m MB"
echo "             "
echo "•Ram Used : $memUsed_m MB / $memUsedPrc% "
echo "             "
echo '•CPU Used : '"$CPUPer"'%'
echo "            "
echo '•IN RUNNING Apps : '"$ProcessCnt"
echo "             "
echo '•Uptime : '"$uptime"
echo "             "
echo "             "
echo "@UltraSpy    "
